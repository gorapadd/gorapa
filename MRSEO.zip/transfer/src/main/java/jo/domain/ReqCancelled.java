package jo.domain;

import java.util.Date;
import jo.domain.*;
import jo.infra.AbstractEvent;
import lombok.Data;

@Data
public class ReqCancelled extends AbstractEvent {

    private Long id;
    private String acctNo;
    private String tranId;
    private String tranType;
    private Double tranAmt;
    private String cusTelNo;
    private String cusName;
    private String recvAcctno;
    // keep

}
