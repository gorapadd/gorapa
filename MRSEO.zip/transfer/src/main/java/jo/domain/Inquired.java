package jo.domain;

import java.util.Date;
import jo.domain.*;
import jo.infra.AbstractEvent;
import lombok.Data;

@Data
public class Inquired extends AbstractEvent {

    private Long id;
    private String acctNo;
    private String tranId;

    public Inquired(Transfer aggregate) {
        super(aggregate);
    }

    public Inquired() {
        super();
    }
    // keep

}
