package jo.domain;

import java.util.List;

public interface AcctInfoService {
    int acctInfoSize(String acctNo);  
}
