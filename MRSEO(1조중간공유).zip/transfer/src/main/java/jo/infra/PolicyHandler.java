package jo.infra;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import javax.naming.NameParser;
import javax.naming.NameParser;
import javax.transaction.Transactional;
import jo.config.kafka.KafkaProcessor;
import jo.domain.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class PolicyHandler {

    @Autowired
    TransferRepository transferRepository;

    @StreamListener(KafkaProcessor.INPUT)
    public void whatever(@Payload String eventString) {}

    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverReqInquired_Inquire(@Payload ReqInquired reqInquired) {
        if (!reqInquired.validate()) return;
        ReqInquired event = reqInquired;
        System.out.println(
            "\n\n##### listener Inquire : " + reqInquired.toJson() + "\n\n"
        );

        // Sample Logic //
        Transfer.inquire(event);
    }

    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverReqCancelled_Cancel(
        @Payload ReqCancelled reqCancelled
    ) {
        if (!reqCancelled.validate()) return;
        ReqCancelled event = reqCancelled;
        System.out.println(
            "\n\n##### listener Cancel : " + reqCancelled.toJson() + "\n\n"
        );

        // Sample Logic //
        Transfer.cancel(event);
    }

    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverReqTransferred_Transfer(
        @Payload ReqTransferred reqTransferred
    ) {
        if (!reqTransferred.validate()) return;
        ReqTransferred event = reqTransferred;
        System.out.println(
            "\n\n##### listener Transfer : " + reqTransferred.toJson() + "\n\n"
        );

        // Sample Logic //
        Transfer.transfer(event);
    }
    // keep

}
