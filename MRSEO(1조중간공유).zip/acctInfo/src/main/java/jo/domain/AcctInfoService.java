package jo.domain;

import java.util.List;

public interface AcctInfoService {
    int acctNoCnt(String acctNo);  
}
